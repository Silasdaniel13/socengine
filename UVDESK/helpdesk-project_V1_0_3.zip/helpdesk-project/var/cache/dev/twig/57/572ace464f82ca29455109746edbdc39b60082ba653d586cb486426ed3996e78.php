<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @UVDeskSupportCenter/Knowledgebase/ticketView.html.twig */
class __TwigTemplate_914cbda3fc17d61fc0d95d2a20db94fa13ec4d6d281273b631e6401661772cd5 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'ogtitle' => [$this, 'block_ogtitle'],
            'twtitle' => [$this, 'block_twtitle'],
            'tabHeader' => [$this, 'block_tabHeader'],
            'body' => [$this, 'block_body'],
            'footer' => [$this, 'block_footer'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "@UVDeskSupportCenter/Templates/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@UVDeskSupportCenter/Knowledgebase/ticketView.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@UVDeskSupportCenter/Knowledgebase/ticketView.html.twig"));

        $this->parent = $this->loadTemplate("@UVDeskSupportCenter/Templates/layout.html.twig", "@UVDeskSupportCenter/Knowledgebase/ticketView.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "#";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["ticket"]) || array_key_exists("ticket", $context) ? $context["ticket"] : (function () { throw new RuntimeError('Variable "ticket" does not exist.', 3, $this->source); })()), "id", [], "any", false, false, false, 3), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["ticket"]) || array_key_exists("ticket", $context) ? $context["ticket"] : (function () { throw new RuntimeError('Variable "ticket" does not exist.', 3, $this->source); })()), "subject", [], "any", false, false, false, 3), "html", null, true);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 4
    public function block_ogtitle($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "ogtitle"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "ogtitle"));

        echo "#";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["ticket"]) || array_key_exists("ticket", $context) ? $context["ticket"] : (function () { throw new RuntimeError('Variable "ticket" does not exist.', 4, $this->source); })()), "id", [], "any", false, false, false, 4), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["ticket"]) || array_key_exists("ticket", $context) ? $context["ticket"] : (function () { throw new RuntimeError('Variable "ticket" does not exist.', 4, $this->source); })()), "subject", [], "any", false, false, false, 4), "html", null, true);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_twtitle($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "twtitle"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "twtitle"));

        echo "#";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["ticket"]) || array_key_exists("ticket", $context) ? $context["ticket"] : (function () { throw new RuntimeError('Variable "ticket" does not exist.', 5, $this->source); })()), "id", [], "any", false, false, false, 5), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["ticket"]) || array_key_exists("ticket", $context) ? $context["ticket"] : (function () { throw new RuntimeError('Variable "ticket" does not exist.', 5, $this->source); })()), "subject", [], "any", false, false, false, 5), "html", null, true);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 7
    public function block_tabHeader($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "tabHeader"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "tabHeader"));

        // line 8
        echo "\t<div class=\"uv-nav-bar uv-nav-tab\">
\t\t<div class=\"uv-container\">
\t\t\t<div class=\"uv-nav-bar-lt\">
\t\t\t\t<ul class=\"uv-nav-tab-label\">
\t\t\t\t\t<li><a href=\"";
        // line 12
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("helpdesk_customer_ticket_collection");
        echo "\">";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Ticket Requests"), "html", null, true);
        echo "</a></li>
\t\t\t\t\t";
        // line 13
        if (twig_get_attribute($this->env, $this->source, (isset($context["websiteConfiguration"]) || array_key_exists("websiteConfiguration", $context) ? $context["websiteConfiguration"] : (function () { throw new RuntimeError('Variable "websiteConfiguration" does not exist.', 13, $this->source); })()), "ticketCreateOption", [], "any", false, false, false, 13)) {
            // line 14
            echo "                        <li><a href=\"";
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("helpdesk_customer_create_ticket");
            echo "\">";
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("New Ticket Request"), "html", null, true);
            echo "</a></li>
                    ";
        }
        // line 16
        echo "\t\t\t\t</ul>
\t\t\t</div>
\t\t\t<div class=\"uv-nav-bar-rt\">
\t\t\t\t<form method=\"get\" action=\"";
        // line 19
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("helpdesk_customer_front_article_search");
        echo "\">
\t\t\t\t\t<input name=\"s\" class=\"uv-nav-search\" type=\"text\" placeholder=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Search"), "html", null, true);
        echo "\">
\t\t\t\t</form>
\t\t\t</div>
\t\t</div>
\t</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 27
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 28
        echo "    <style>
        .uv-btn-tag {
            margin-right: 5px;
        }
        .uv-group-field {
            width: 80%;
        }
        .uv-element-block .mce-tinymce {
            margin-top: 10px;
        }
        .uv-ticket-view .uv-ticket-accordion .uv-ticket-wrapper {
            display: block;
        }
        .message {
            font-size: 15px;
        }
        .message img {
            max-width: 100%;
        }
        .uv-dropdown.reply .uv-dropdown-btn-active {
            border: none;
        }
        .uv-dropdown.reply .uv-dropdown-list {
            width: 220px;
            bottom: 47px;
        }

\t\t.uv-rtl .uv-top-left {
\t\t\tleft: unset;
\t\t}

\t\t.uv-rtl .uv-dropdown-list {
\t\t\ttext-align: right;
\t\t}

        .uv-action-buttons {
            margin: 10px 0px;
        }

        .uv-action-buttons .uv-btn:first-child {
            margin-left: 0px;
        }

\t\t.uv-rtl .uv-action-buttons .uv-btn:first-child {
\t\t\tmargin-left: 5px;
\t\t\tmargin-right: 0px;
\t\t}

        .uv-action-buttons .uv-btn {
            margin: 5px;
        }

        form #customFieldCollection .uv-field-error-icon, form #customFieldCollection .uv-field-success-icon {
            display: none;
        }

        .custom-field-field-display .uv-field-block {
            width: 100%;
            color: #333333;
            word-wrap: break-word;
        }

        .custom-field-field-display .uv-field-block span {
            display: inline;
        }
        .uv-submit-left-side {
            margin: 0!important;
            padding-right: 5px;
            border-bottom-right-radius: 0;
            border-top-right-radius: 0;
        }
\t\t.uv-rtl .uv-submit-left-side {
\t\t\tpadding-right: 10px;
            border-bottom-right-radius: 3px;
            border-top-right-radius: 3px;
\t\t\tpadding-left: 5px;
\t\t\tborder-bottom-left-radius: 0;
            border-top-left-radius: 0;
\t\t}
        .uv-submit-right-side {
            margin: 0!important;
        }
        .no-left-padding {
            padding-left: 0;
            border-bottom-left-radius: 0;
            border-top-left-radius: 0;
        }
\t\t.uv-rtl .no-left-padding {
\t\t\tpadding-left: 10px;
            border-bottom-left-radius: 3px;
            border-top-left-radius: 3px;
\t\t\tpadding-right: 0;
\t\t\tborder-bottom-right-radius: 0;
\t\t\tborder-top-right-radius: 0;
\t\t}
        .uv-btn-error {
            background-color: #FF5656!important;
        }
        .uv-pull-rightside {
            float: right;
            font-size: 15px;
            cursor: pointer;
        }
\t\t.uv-rtl .uv-pull-rightside {
            float: left;
        }
        .uv-print-icon {
            display: inline-block;
            width: 20px;
            height: 20px;
            background-image: url('../../../../../bundles/webkuldefault/images/uvdesk-kb-sprite.svg');
            background-position: -176px -91px;
            vertical-align: middle;
        }
        @media print {
            .uv-navbar,.uv-ticket-action-bar, .uv-kudo, .uv-aside-back, .uv-footer, .uv-ticket-main.uv-ticket-reply, .uv-nav-bar,input, .uv-dropdown-list>.uv-dropdown-container,.uv-notifications-wrapper,.uv-pop-up-overlay,.uv-loader-view, .uv-loader,.uv-header,.uv-upload-actions,.uv-pull-rightside {
                display: none !important;
            }
        }
        blockquote {
            background: #f9f9f9;
            border-left: 4px solid #ccc;
            margin: 1.5em 10px;
            padding: 0.5em 10px;
            quotes: \"\\201C\"\"\\201D\"\"\\2018\"\"\\2019\";
        }
        blockquote:before {
            color: #ccc;
            content: open-quote;
            font-size: 3em;
            line-height: 0.1em;
            margin-right: 0.05em;
            vertical-align: -0.4em;
        }
        blockquote p {
            display: inline;
        }
    </style>

    ";
        // line 167
        $context["ticketAgent"] = ((twig_get_attribute($this->env, $this->source, (isset($context["ticket"]) || array_key_exists("ticket", $context) ? $context["ticket"] : (function () { throw new RuntimeError('Variable "ticket" does not exist.', 167, $this->source); })()), "agent", [], "any", false, false, false, 167)) ? (twig_get_attribute($this->env, $this->source, (isset($context["user_service"]) || array_key_exists("user_service", $context) ? $context["user_service"] : (function () { throw new RuntimeError('Variable "user_service" does not exist.', 167, $this->source); })()), "getAgentDetailById", [0 => twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["ticket"]) || array_key_exists("ticket", $context) ? $context["ticket"] : (function () { throw new RuntimeError('Variable "ticket" does not exist.', 167, $this->source); })()), "agent", [], "any", false, false, false, 167), "id", [], "any", false, false, false, 167)], "method", false, false, false, 167)) : (null));
        // line 168
        echo "    ";
        $context["totalThreads"] = twig_get_attribute($this->env, $this->source, (isset($context["ticket_service"]) || array_key_exists("ticket_service", $context) ? $context["ticket_service"] : (function () { throw new RuntimeError('Variable "ticket_service" does not exist.', 168, $this->source); })()), "getTicketTotalThreads", [0 => twig_get_attribute($this->env, $this->source, (isset($context["ticket"]) || array_key_exists("ticket", $context) ? $context["ticket"] : (function () { throw new RuntimeError('Variable "ticket" does not exist.', 168, $this->source); })()), "id", [], "any", false, false, false, 168)], "method", false, false, false, 168);
        // line 169
        echo "    ";
        $context["customer"] = twig_get_attribute($this->env, $this->source, (isset($context["user_service"]) || array_key_exists("user_service", $context) ? $context["user_service"] : (function () { throw new RuntimeError('Variable "user_service" does not exist.', 169, $this->source); })()), "getCustomerPartialDetailById", [0 => twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["ticket"]) || array_key_exists("ticket", $context) ? $context["ticket"] : (function () { throw new RuntimeError('Variable "ticket" does not exist.', 169, $this->source); })()), "customer", [], "any", false, false, false, 169), "id", [], "any", false, false, false, 169)], "method", false, false, false, 169);
        // line 170
        echo "    ";
        $context["createThread"] = twig_get_attribute($this->env, $this->source, (isset($context["ticket_service"]) || array_key_exists("ticket_service", $context) ? $context["ticket_service"] : (function () { throw new RuntimeError('Variable "ticket_service" does not exist.', 170, $this->source); })()), "getCreateReply", [0 => twig_get_attribute($this->env, $this->source, (isset($context["ticket"]) || array_key_exists("ticket", $context) ? $context["ticket"] : (function () { throw new RuntimeError('Variable "ticket" does not exist.', 170, $this->source); })()), "id", [], "any", false, false, false, 170), 1 => "customer"], "method", false, false, false, 170);
        // line 171
        echo "    ";
        $context["currentUser"] = twig_get_attribute($this->env, $this->source, (isset($context["user_service"]) || array_key_exists("user_service", $context) ? $context["user_service"] : (function () { throw new RuntimeError('Variable "user_service" does not exist.', 171, $this->source); })()), "getCustomerPartialDetailById", [0 => twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 171, $this->source); })()), "user", [], "any", false, false, false, 171), "id", [], "any", false, false, false, 171)], "method", false, false, false, 171);
        // line 172
        echo "
    <div class=\"uv-thread\">
        <div class=\"uv-thread-lt\">
            <aside>
                <h6>";
        // line 176
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Ticket Information"), "html", null, true);
        echo "</h6>
                <div class=\"uv-aside-brick\">
                    <h6>";
        // line 178
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Total Replies"), "html", null, true);
        echo "</h6>
                    <span class=\"uv-icon-replies\"></span>
                    <span>";
        // line 180
        echo twig_escape_filter($this->env, (isset($context["totalThreads"]) || array_key_exists("totalThreads", $context) ? $context["totalThreads"] : (function () { throw new RuntimeError('Variable "totalThreads" does not exist.', 180, $this->source); })()), "html", null, true);
        echo "</span>
                </div>
                <div class=\"uv-aside-brick\">
                    <h6>";
        // line 183
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Timestamp"), "html", null, true);
        echo "</h6>
                    <span class=\"uv-icon-timestamp\"></span>
                    <span>";
        // line 185
        echo twig_escape_filter($this->env, (isset($context["localizedCreateAtTime"]) || array_key_exists("localizedCreateAtTime", $context) ? $context["localizedCreateAtTime"] : (function () { throw new RuntimeError('Variable "localizedCreateAtTime" does not exist.', 185, $this->source); })()), "html", null, true);
        echo "</span>
                </div>

                <div class=\"uv-hr\"></div>
                ";
        // line 189
        if ((twig_get_attribute($this->env, $this->source, (isset($context["ticket"]) || array_key_exists("ticket", $context) ? $context["ticket"] : (function () { throw new RuntimeError('Variable "ticket" does not exist.', 189, $this->source); })()), "customer", [], "any", false, false, false, 189) != twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 189, $this->source); })()), "user", [], "any", false, false, false, 189))) {
            // line 190
            echo "                    <div class=\"uv-aside-brick\">
                        <h6>";
            // line 191
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Customer"), "html", null, true);
            echo "</h6>
                        <span>";
            // line 192
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["customer"]) || array_key_exists("customer", $context) ? $context["customer"] : (function () { throw new RuntimeError('Variable "customer" does not exist.', 192, $this->source); })()), "name", [], "any", false, false, false, 192), "html", null, true);
            echo "</span>
                    </div>
                ";
        }
        // line 195
        echo "                ";
        if ((isset($context["ticketAgent"]) || array_key_exists("ticketAgent", $context) ? $context["ticketAgent"] : (function () { throw new RuntimeError('Variable "ticketAgent" does not exist.', 195, $this->source); })())) {
            // line 196
            echo "                    <div class=\"uv-aside-brick\">
                        <h6>";
            // line 197
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Agent"), "html", null, true);
            echo "</h6>
                        <span>";
            // line 198
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["ticketAgent"]) || array_key_exists("ticketAgent", $context) ? $context["ticketAgent"] : (function () { throw new RuntimeError('Variable "ticketAgent" does not exist.', 198, $this->source); })()), "name", [], "any", false, false, false, 198), "html", null, true);
            echo "</span>
                    </div>
                ";
        }
        // line 201
        echo "                <div class=\"uv-aside-brick\">
                    <h6>";
        // line 202
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Status"), "html", null, true);
        echo "</h6>
                    <span>";
        // line 203
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["ticket"]) || array_key_exists("ticket", $context) ? $context["ticket"] : (function () { throw new RuntimeError('Variable "ticket" does not exist.', 203, $this->source); })()), "status", [], "any", false, false, false, 203), "description", [], "any", false, false, false, 203)), "html", null, true);
        echo "</span>
                </div>
                ";
        // line 205
        if (twig_get_attribute($this->env, $this->source, (isset($context["ticket"]) || array_key_exists("ticket", $context) ? $context["ticket"] : (function () { throw new RuntimeError('Variable "ticket" does not exist.', 205, $this->source); })()), "type", [], "any", false, false, false, 205)) {
            // line 206
            echo "                    <div class=\"uv-aside-brick\">
                        <h6>";
            // line 207
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Type"), "html", null, true);
            echo "</h6>
                        <span>";
            // line 208
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["ticket"]) || array_key_exists("ticket", $context) ? $context["ticket"] : (function () { throw new RuntimeError('Variable "ticket" does not exist.', 208, $this->source); })()), "type", [], "any", false, false, false, 208), "code", [], "any", false, false, false, 208), "html", null, true);
            echo "</span>
                    </div>
                ";
        }
        // line 211
        echo "
                ";
        // line 212
        if ((twig_get_attribute($this->env, $this->source, (isset($context["ticket"]) || array_key_exists("ticket", $context) ? $context["ticket"] : (function () { throw new RuntimeError('Variable "ticket" does not exist.', 212, $this->source); })()), "customer", [], "any", false, false, false, 212) == twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 212, $this->source); })()), "user", [], "any", false, false, false, 212))) {
            // line 213
            echo "                    <div class=\"uv-hr\"></div>
                    <div class=\"uv-aside-brick collaborator-list-block\">
                        <div class=\"uv-element-block\">
                            <label class=\"uv-field-label\">";
            // line 216
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Collaborators"), "html", null, true);
            echo "</label>
                            <div class=\"uv-field-block\">
                                <input class=\"uv-field\" type=\"text\" name=\"email\" type=\"text\" value=\"\" placeholder=\"";
            // line 218
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Type email to add"), "html", null, true);
            echo "\">
                            </div>
                        </div>
                        <div class=\"collaborator-list\" style=\"margin-top: 10px\">
                        </div>
                    </div>
                ";
        }
        // line 225
        echo "            </aside>
            ";
        // line 226
        if ((isset($context["customFieldCollection"]) || array_key_exists("customFieldCollection", $context))) {
            // line 227
            echo "                <aside id=\"uv-customfield-view\" class=\"uv-customfield-view\" style=\"margin-top: 20px;\">
                    <div style=\"position: relative;\">
                        <h6>";
            // line 229
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Custom Field"), "html", null, true);
            echo "</h6>
                        <span class=\"uv-customize cfield-manage-pta\" style=\"width: 15px; height: 15px; position: absolute; background-image: url('../../../../../bundles/webkuldefault/images/uvdesk-sprite.svg'); background-position: -44px -46px; top: 4px; cursor: pointer;\" title=\"";
            // line 230
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Manage Ticket Custom Fields"), "html", null, true);
            echo "\" data-toggle=\"tooltip\" data-placement=\"bottom\"></span>
                    </div>
                    <p style=\"padding-right: 20px; color: #6F6F6F; font-style: italic;\">";
            // line 232
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Manage Custom Fields to provide additional details with the ticket."), "html", null, true);
            echo "</p>

                    <div class=\"uv-hr\"></div>
                    <form name=\"customFieldForm\" enctype=\"multipart/form-data\">
                        <div id=\"customFieldCollection\">
                        </div>
                    </form>
                </aside>
            ";
        }
        // line 241
        echo "        </div>
        <div class=\"uv-thread-rt\">
            <section>
                <div class=\"uv-ticket-view\">
                    <div class=\"uv-ticket-head\">
                        <h1>
                            ";
        // line 247
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["ticket"]) || array_key_exists("ticket", $context) ? $context["ticket"] : (function () { throw new RuntimeError('Variable "ticket" does not exist.', 247, $this->source); })()), "subject", [], "any", false, false, false, 247), "html", null, true);
        echo "
                            <span class=\"uv-pull-rightside uv-print-icon\" onclick=\"window.print()\"></span>
                        </h1>
                        <div class=\"uv-ticket-strip\">
                            <span>
                                <span class=\"uv-ticket-strip-label\">";
        // line 252
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Created"), "html", null, true);
        echo " -</span>
                                <span class=\"timeago\" data-timestamp=\"";
        // line 253
        echo twig_escape_filter($this->env, (isset($context["localizedCreateAtTime"]) || array_key_exists("localizedCreateAtTime", $context) ? $context["localizedCreateAtTime"] : (function () { throw new RuntimeError('Variable "localizedCreateAtTime" does not exist.', 253, $this->source); })()), "html", null, true);
        echo "\" title=\"";
        echo twig_escape_filter($this->env, (isset($context["localizedCreateAtTime"]) || array_key_exists("localizedCreateAtTime", $context) ? $context["localizedCreateAtTime"] : (function () { throw new RuntimeError('Variable "localizedCreateAtTime" does not exist.', 253, $this->source); })()), "html", null, true);
        echo "\">
                                    ";
        // line 254
        echo twig_escape_filter($this->env, (isset($context["localizedCreateAtTime"]) || array_key_exists("localizedCreateAtTime", $context) ? $context["localizedCreateAtTime"] : (function () { throw new RuntimeError('Variable "localizedCreateAtTime" does not exist.', 254, $this->source); })()), "html", null, true);
        echo " 
                                </span>
                            </span>
                            <span>
                                <span class=\"uv-ticket-strip-label\">";
        // line 258
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("By"), "html", null, true);
        echo " -</span>
                                ";
        // line 259
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["createThread"]) || array_key_exists("createThread", $context) ? $context["createThread"] : (function () { throw new RuntimeError('Variable "createThread" does not exist.', 259, $this->source); })()), "user", [], "any", false, false, false, 259), "name", [], "any", false, false, false, 259), "html", null, true);
        echo "
                            </span>
                            ";
        // line 261
        if ((isset($context["ticketAgent"]) || array_key_exists("ticketAgent", $context) ? $context["ticketAgent"] : (function () { throw new RuntimeError('Variable "ticketAgent" does not exist.', 261, $this->source); })())) {
            // line 262
            echo "                                <span>
                                    <span class=\"uv-ticket-strip-label\">";
            // line 263
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Agent"), "html", null, true);
            echo " -</span>
                                    ";
            // line 264
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["ticketAgent"]) || array_key_exists("ticketAgent", $context) ? $context["ticketAgent"] : (function () { throw new RuntimeError('Variable "ticketAgent" does not exist.', 264, $this->source); })()), "name", [], "any", false, false, false, 264), "html", null, true);
            echo "
                                </span>
                            ";
        }
        // line 267
        echo "                        </div>
                    </div>

                    <div class=\"uv-tab-view\">
                        <div class=\"uv-ticket-section\">
                            <div class=\"uv-ticket-main create\">
                                <div class=\"uv-ticket-strip\">
                                    <span>
                                        <span class=\"timeago uv-margin-0\" data-timestamp=\"ticket.createdAt\" title=\"";
        // line 275
        echo twig_escape_filter($this->env, (isset($context["localizedCreateAtTime"]) || array_key_exists("localizedCreateAtTime", $context) ? $context["localizedCreateAtTime"] : (function () { throw new RuntimeError('Variable "localizedCreateAtTime" does not exist.', 275, $this->source); })()), "html", null, true);
        echo "\">
                                            ";
        // line 276
        echo twig_escape_filter($this->env, (isset($context["localizedCreateAtTime"]) || array_key_exists("localizedCreateAtTime", $context) ? $context["localizedCreateAtTime"] : (function () { throw new RuntimeError('Variable "localizedCreateAtTime" does not exist.', 276, $this->source); })()), "html", null, true);
        echo "
                                        </span>
                                        - ";
        // line 278
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["createThread"]) || array_key_exists("createThread", $context) ? $context["createThread"] : (function () { throw new RuntimeError('Variable "createThread" does not exist.', 278, $this->source); })()), "user", [], "any", false, false, false, 278), "name", [], "any", false, false, false, 278), "html", null, true);
        echo "
                                        <span class=\"uv-ticket-strip-label\">
                                        ";
        // line 280
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("created Ticket"), "html", null, true);
        echo "
                                        ";
        // line 284
        echo "                                    </span>
                                </span>
                                </div>
                                <div class=\"uv-ticket-main-lt\">
                                   <img src=\"";
        // line 288
        echo twig_escape_filter($this->env, ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["initialThread"]) || array_key_exists("initialThread", $context) ? $context["initialThread"] : (function () { throw new RuntimeError('Variable "initialThread" does not exist.', 288, $this->source); })()), "user", [], "any", false, false, false, 288), "thumbnail", [], "any", false, false, false, 288)) ? (((((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 288, $this->source); })()), "request", [], "any", false, false, false, 288), "scheme", [], "any", false, false, false, 288) . "://") . twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 288, $this->source); })()), "request", [], "any", false, false, false, 288), "httpHost", [], "any", false, false, false, 288)) . $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("")) . twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["initialThread"]) || array_key_exists("initialThread", $context) ? $context["initialThread"] : (function () { throw new RuntimeError('Variable "initialThread" does not exist.', 288, $this->source); })()), "user", [], "any", false, false, false, 288), "thumbnail", [], "any", false, false, false, 288))) : ((((twig_get_attribute($this->env, $this->source, (isset($context["initialThread"]) || array_key_exists("initialThread", $context) ? $context["initialThread"] : (function () { throw new RuntimeError('Variable "initialThread" does not exist.', 288, $this->source); })()), "createdBy", [], "any", false, false, false, 288) == "customer")) ? ($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl((isset($context["default_customer_image_path"]) || array_key_exists("default_customer_image_path", $context) ? $context["default_customer_image_path"] : (function () { throw new RuntimeError('Variable "default_customer_image_path" does not exist.', 288, $this->source); })()))) : ($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl((isset($context["default_agent_image_path"]) || array_key_exists("default_agent_image_path", $context) ? $context["default_agent_image_path"] : (function () { throw new RuntimeError('Variable "default_agent_image_path" does not exist.', 288, $this->source); })())))))), "html", null, true);
        echo "\">
                                </div>
                                <div class=\"uv-ticket-main-rt\">
                                    <span class=\"uv-ticket-member-name\">
                                        ";
        // line 292
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["createThread"]) || array_key_exists("createThread", $context) ? $context["createThread"] : (function () { throw new RuntimeError('Variable "createThread" does not exist.', 292, $this->source); })()), "user", [], "any", false, false, false, 292), "name", [], "any", false, false, false, 292), "html", null, true);
        echo "
                                    </span>

                                    <!-- Message Block -->
                                    <div class=\"message\">
                                        <p>
                                            ";
        // line 298
        if ((strip_tags(twig_get_attribute($this->env, $this->source, (isset($context["createThread"]) || array_key_exists("createThread", $context) ? $context["createThread"] : (function () { throw new RuntimeError('Variable "createThread" does not exist.', 298, $this->source); })()), "reply", [], "any", false, false, false, 298)) == twig_get_attribute($this->env, $this->source, (isset($context["createThread"]) || array_key_exists("createThread", $context) ? $context["createThread"] : (function () { throw new RuntimeError('Variable "createThread" does not exist.', 298, $this->source); })()), "reply", [], "any", false, false, false, 298))) {
            // line 299
            echo "                                                ";
            echo nl2br(twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["createThread"]) || array_key_exists("createThread", $context) ? $context["createThread"] : (function () { throw new RuntimeError('Variable "createThread" does not exist.', 299, $this->source); })()), "reply", [], "any", false, false, false, 299), "html", null, true));
            echo "
                                            ";
        } else {
            // line 301
            echo "                                                ";
            echo twig_get_attribute($this->env, $this->source, (isset($context["createThread"]) || array_key_exists("createThread", $context) ? $context["createThread"] : (function () { throw new RuntimeError('Variable "createThread" does not exist.', 301, $this->source); })()), "reply", [], "any", false, false, false, 301);
            echo "
                                            ";
        }
        // line 303
        echo "                                        </p>
                                    </div>
                                    <!-- //Message Block -->

                                    <!-- Attachment Block -->
                                    ";
        // line 308
        if (twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["createThread"]) || array_key_exists("createThread", $context) ? $context["createThread"] : (function () { throw new RuntimeError('Variable "createThread" does not exist.', 308, $this->source); })()), "attachments", [], "any", false, false, false, 308))) {
            // line 309
            echo "                                        <div class=\"uv-ticket-uploads\">
                                            <h4>";
            // line 310
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Uploaded Files"), "html", null, true);
            echo "</h4>
                                            <div class=\"uv-ticket-uploads-strip uv-viewer-images\">
                                                ";
            // line 312
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["createThread"]) || array_key_exists("createThread", $context) ? $context["createThread"] : (function () { throw new RuntimeError('Variable "createThread" does not exist.', 312, $this->source); })()), "attachments", [], "any", false, false, false, 312));
            foreach ($context['_seq'] as $context["_key"] => $context["attachment"]) {
                // line 313
                echo "                                                    <a href=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["attachment"], "downloadURL", [], "any", false, false, false, 313), "html", null, true);
                echo "\" target = \"_blank\" class=\"uv-ticket-uploads-brick uv-no-pointer-events\" data-toggle=\"tooltip\" title=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["attachment"], "name", [], "any", false, false, false, 313), "html", null, true);
                echo "\">
                                                        <img src=\"";
                // line 314
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["attachment"], "iconURL", [], "any", false, false, false, 314), "html", null, true);
                echo "\"  class=\"uv-auto-pointer-events\"/>
                                                    </a>
                                                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['attachment'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 317
            echo "                                            </div>
                                            ";
            // line 318
            if ((twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["createThread"]) || array_key_exists("createThread", $context) ? $context["createThread"] : (function () { throw new RuntimeError('Variable "createThread" does not exist.', 318, $this->source); })()), "attachments", [], "any", false, false, false, 318)) > 1)) {
                // line 319
                echo "                                                <div class=\"uv-upload-actions\">
                                                    <!-- <a href=\"#\"><span class=\"uv-icon-open-in-files\"></span>Open in Files</a> -->
                                                    <a href=\"";
                // line 321
                echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("helpdesk_customer_download_ticket_attachment_zip");
                echo "/";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["createThread"]) || array_key_exists("createThread", $context) ? $context["createThread"] : (function () { throw new RuntimeError('Variable "createThread" does not exist.', 321, $this->source); })()), "id", [], "any", false, false, false, 321), "html", null, true);
                echo "\" target=\"_blank\"><span class=\"uv-icon-attachment\"></span> ";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Download (as .zip)"), "html", null, true);
                echo "</a>
                                                </div>
                                            ";
            }
            // line 324
            echo "                                        </div>
                                    ";
        }
        // line 326
        echo "                                    <!-- //Attachment Block -->
                                </div>
                            </div>

                            <!-- uv-ticket-accordion-expanded uv-ticket-accordion-no-count-->
                            <div class=\"uv-ticket-accordion\">
                                <div class=\"uv-ticket-count-wrapper\">
                                    <span class=\"uv-ticket-count-stat\">";
        // line 333
        echo twig_escape_filter($this->env, (isset($context["totalThreads"]) || array_key_exists("totalThreads", $context) ? $context["totalThreads"] : (function () { throw new RuntimeError('Variable "totalThreads" does not exist.', 333, $this->source); })()), "html", null, true);
        echo "</span>
                                </div>
                                <div class=\"uv-ticket-wrapper thread-list\">
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Reply Form Block -->
                    <div class=\"uv-ticket-main uv-ticket-reply uv-no-error-success-icon\">
                        <div class=\"uv-ticket-main-lt\">
                            <span class=\"uv-icon-ellipsis\"></span>
                            ";
        // line 345
        if (twig_get_attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 345, $this->source); })()), "smallThumbnail", [], "any", false, false, false, 345)) {
            // line 346
            echo "                                <img src=\"";
            echo twig_escape_filter($this->env, (((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 346, $this->source); })()), "request", [], "any", false, false, false, 346), "scheme", [], "any", false, false, false, 346) . "://") . twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 346, $this->source); })()), "request", [], "any", false, false, false, 346), "httpHost", [], "any", false, false, false, 346)) . $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("")), "html", null, true);
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 346, $this->source); })()), "smallThumbnail", [], "any", false, false, false, 346), "html", null, true);
            echo "\" />
                            ";
        } else {
            // line 348
            echo "                                <img src=\"";
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl((isset($context["default_customer_image_path"]) || array_key_exists("default_customer_image_path", $context) ? $context["default_customer_image_path"] : (function () { throw new RuntimeError('Variable "default_customer_image_path" does not exist.', 348, $this->source); })())), "html", null, true);
            echo "\" />
                            ";
        }
        // line 350
        echo "                        </div>
                        <div class=\"uv-ticket-main-rt\">
                            <span class=\"uv-ticket-member-name\">";
        // line 352
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 352, $this->source); })()), "name", [], "any", false, false, false, 352), "html", null, true);
        echo "</span>

                            <!-- Reply Tab View -->
                            <div class=\"uv-tab-view uv-tab-view-active\" id=\"reply\">
                                <form enctype=\"multipart/form-data\" method=\"post\" action=\"";
        // line 356
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("helpdesk_customer_add_ticket_thread", ["id" => twig_get_attribute($this->env, $this->source, (isset($context["ticket"]) || array_key_exists("ticket", $context) ? $context["ticket"] : (function () { throw new RuntimeError('Variable "ticket" does not exist.', 356, $this->source); })()), "id", [], "any", false, false, false, 356)]), "html", null, true);
        echo "\" id=\"ticket-form\">
                                    <input name=\"threadType\" value=\"reply\" type=\"hidden\">
                                    <input class=\"reply-status\" name=\"status\" value=\"\" type=\"hidden\">
                                    <div class=\"uv-element-block collaborators\" style=\"display: none\">
                                        <label class=\"uv-field-label\">";
        // line 360
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Collaborators"), "html", null, true);
        echo "</label>
                                        <div class=\"uv-field-block\">
                                        </div>
                                    </div>

                                    <div class=\"uv-element-block cc-bcc\">
                                        <label>
                                            <div class=\"uv-checkbox\">
                                                <input type=\"checkbox\" class=\"cc-bcc-toggle\">
                                                <span class=\"uv-checkbox-view\"></span>
                                            </div>
                                            <span class=\"uv-checkbox-label\">";
        // line 371
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("CC/BCC"), "html", null, true);
        echo "</span>
                                        </label>
                                        <div class=\"uv-field-block\" style=\"display: none\">
                                            <div class=\"uv-group\">
                                                <input class=\"uv-group-field\" type=\"text\">
                                                <select class=\"uv-group-select cc-bcc-select\">
                                                    <option value=\"bcc\">";
        // line 377
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("BCC"), "html", null, true);
        echo "</option>
                                                    <option value=\"cc\">";
        // line 378
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("CC"), "html", null, true);
        echo "</option>
                                                </select>
                                            </div>
                                            <div class=\"cc-bcc-list\">
                                            </div>
                                        </div>
                                    </div>

                                    <div class=\"uv-element-block uv-element-block-textarea\">
                                        <label class=\"uv-field-label\">";
        // line 387
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Write a reply"), "html", null, true);
        echo "</label>
                                        <div class=\"uv-field-block\">
                                            <textarea class=\"uv-field\" name=\"message\" id=\"reply-area\">";
        // line 389
        echo "</textarea>
                                        </div>
                                    </div>

                                    <!-- Field -->
                                    <div class=\"uv-element-block attachment-block\">
                                        <label>
                                            <span class=\"uv-file-label\">";
        // line 396
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Add Attachment"), "html", null, true);
        echo "</span>
                                        </label>
                                    </div>
                                    <!-- //Field -->

                                    <div class=\"uv-action-buttons\">
                                        <div id=\"reply-btn\" class=\"uv-btn uv-submit-left-side\">";
        // line 402
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Reply"), "html", null, true);
        echo "</div>
                                        <div class=\"uv-dropdown reply uv-submit-right-side\">
                                            <div class=\"uv-btn uv-dropdown-other no-left-padding\">
                                                <span class=\"uv-icon-down-light\"></span>
                                            </div>
                                            <div class=\"uv-dropdown-list uv-top-left\">
                                                <div class=\"uv-dropdown-container\">
                                                    <label>";
        // line 409
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Reply"), "html", null, true);
        echo "</label>
                                                    <ul>
                                                        <li data-id=\"\">";
        // line 411
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Submit"), "html", null, true);
        echo "</li>
                                                        <li class=\"confirm-close-ticket\" data-id=\"closed\">";
        // line 412
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Submit And Closed"), "html", null, true);
        echo "</li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <!-- //Reply Tab View -->
                        </div>
                    </div>
                    <!-- Reply Form Block -->
                </div>
            </section>
        </div>
        </div>
    </div>

    <div class=\"uv-pop-up-overlay\" id=\"confirm-ticket-close-modal\" style=\"display: none;\">
        <div class=\"uv-pop-up-box uv-pop-up-slim\">
            <span class=\"uv-pop-up-close\"></span>
            <h2>";
        // line 433
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Confirm Close Ticket"), "html", null, true);
        echo "</h2>
            <p>";
        // line 434
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Are you sure? You want to reply and close ticket."), "html", null, true);
        echo "</p>

            <div class=\"uv-pop-up-actions\">
                <a href=\"#\" class=\"uv-btn uv-btn-error\" id=\"confirmed-close-ticket\" data-id=\"closed\">";
        // line 437
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Confirm"), "html", null, true);
        echo "</a>
                <a href=\"#\" class=\"uv-btn cancel\">";
        // line 438
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Cancel"), "html", null, true);
        echo "</a>
            </div>
        </div>
    </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 444
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footer"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footer"));

        // line 445
        echo "    ";
        $this->displayParentBlock("footer", $context, $blocks);
        echo "
    ";
        // line 446
        echo twig_include($this->env, $context, "@UVDeskCoreFramework/Templates/attachment.html.twig");
        echo "

    <script id=\"thread_list_item_tmp\" type=\"text/template\">
        <div class=\"uv-ticket-strip\">
            <span>
                <span class=\"timeago uv-margin-0\" data-timestamp=\"<%= timestamp %>\" title=\"<%= formatedCreatedAt %>\">
                    <%= formatedCreatedAt %>
                </span>
                - <%- fullname %>
                <span class=\"uv-ticket-strip-label\">
                    ";
        // line 456
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("replied"), "html", null, true);
        echo "
                </span>
            </span>
            <% if(cc || bcc) { %>
                <div class=\"uv-ticket-strip\">
                    <% if(cc) { %>
                        <span><span class=\"uv-ticket-strip-label\">";
        // line 462
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("CC"), "html", null, true);
        echo " -</span> <%- cc %></span>
                    <% } if(bcc) { %>
                        <span><span class=\"uv-ticket-strip-label\">";
        // line 464
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("BCC"), "html", null, true);
        echo " -</span> <%- bcc %></span>
                    <% } %>
                </div>
            <% } %>
        </div>
        <div class=\"uv-ticket-main-lt\">
            <% if(user && smallThumbnail != null) { %>
                <img src=\"";
        // line 471
        echo twig_escape_filter($this->env, (((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 471, $this->source); })()), "request", [], "any", false, false, false, 471), "scheme", [], "any", false, false, false, 471) . "://") . twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 471, $this->source); })()), "request", [], "any", false, false, false, 471), "httpHost", [], "any", false, false, false, 471)) . $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("")), "html", null, true);
        echo "<%= smallThumbnail %>\" />
            <% } else { %>
                <img src=\"<% if(userType == 'agent') { %> ";
        // line 473
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl((isset($context["default_agent_image_path"]) || array_key_exists("default_agent_image_path", $context) ? $context["default_agent_image_path"] : (function () { throw new RuntimeError('Variable "default_agent_image_path" does not exist.', 473, $this->source); })())), "html", null, true);
        echo " <% } else { %> ";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl((isset($context["default_customer_image_path"]) || array_key_exists("default_customer_image_path", $context) ? $context["default_customer_image_path"] : (function () { throw new RuntimeError('Variable "default_customer_image_path" does not exist.', 473, $this->source); })())), "html", null, true);
        echo " <% } %>\" />
            <% } %>
        </div>
        <div class=\"uv-ticket-main-rt\">
            <span class=\"uv-ticket-member-name\">
                <%- fullname %>
            </span>
            <!-- Message Block -->
            <div class=\"message\">
                <%= reply %>
            </div>
            <!-- //Message Block -->

            <!-- Attachment Block -->
            <% if(attachments.length) { %>
                <div class=\"uv-ticket-uploads\">
                    <h4>";
        // line 489
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Uploaded Files"), "html", null, true);
        echo "</h4>
                    <div class=\"uv-ticket-uploads-strip uv-viewer-images\">
                        <% _.each(attachments, function(file) { %>
                            <a href=\"<%-file.downloadURL %>\" target =\"_blank\" class=\"uv-ticket-uploads-brick uv-no-pointer-events\" data-toggle=\"tooltip\" title=\"<%- file.name %>\">
                                <img src=\"<%-file.iconURL %>\" class=\"uv-auto-pointer-events\">
                            </a>
                        <% }) %>
                    </div>

                    <% if (attachments.length > 1) { %>
                        <div class=\"thread-attachments-zip pull-left\">
                            <div class=\"uv-upload-actions\">
                                ";
        // line 502
        echo "                                <a href=\"";
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("helpdesk_customer_download_ticket_attachment_zip");
        echo "/<%= id %>\" target=\"_blank\"><span class=\"uv-icon-attachment\"></span> ";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Download (as .zip)"), "html", null, true);
        echo "</a>
                            </div>
                        </div>
                    <% } %>
                </div>
            <% } %>
            <!-- //Attachment Block -->
        </div>
    </script>

    <script type=\"text/javascript\">

        var ticketApp = {};
        \$(function () {
            
            var TicketModel = Backbone.Model.extend({
                idAttribute : \"id\",
                validation: {
                    'email': [{
                        required: true,
                        msg: '";
        // line 522
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("This field is mandatory"), "html", null, true);
        echo "'
                    },{
                        pattern: 'email',
                        msg: '";
        // line 525
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Please enter a valid email"), "html", null, true);
        echo "'
                    }],
                },
            });

            var TicketView = Backbone.View.extend({
                el: \$('.uv-body'),
                stopDraftSaveFlag: 0,
                events: {
                    'click .collaborator-list .uv-btn-tag': 'removeCcCollaborator',
                    'change .uv-element-block.cc-bcc .cc-bcc-toggle': 'showCcBccBlock',
                    'keypress .uv-element-block.cc-bcc .uv-group-field': 'addCcBccInput',
                    'click .cc-bcc-list .uv-btn-tag, .to-list .uv-btn-tag': 'removeEmail',
                    'click .uv-dropdown.reply .uv-dropdown-list li:not(.confirm-close-ticket)': 'validateForm',
                    'click #reply-btn': 'validateForm',
                    'click #confirmed-close-ticket': 'confirmedAction',
                    'click .confirm-close-ticket': 'confirmClose',
                },
                confirmClose: function(e) {
                    \$('#confirm-ticket-close-modal').show();
                },
                confirmedAction: function(e) {
                    \$('#confirm-ticket-close-modal').hide();
                    this.validateForm(e);
                },
                loaderTemplate : _.template(\$(\"#loader-tmp\").html()),
                addCCCollaborators: function() {
                    if(collaboratorCollection.length) {
                        var collaboratorContainer = \$('.uv-element-block.collaborators');
                        collaboratorContainer.find('.uv-field-block').html('');
                        collaboratorContainer.show()
                        _.each(collaboratorCollection.models, function (item) {
                            var json = item.attributes;
                            collaboratorContainer.find('.uv-field-block').append(\"<span><input type='hidden' name='cccol[]' value='\" + json.email + \"'/><a class='uv-btn-tag' href='#'><span class='uv-icon-remove-dark-before'></span>\" + json.name + \"</a></span>\")
                        }, this);
                    }
                },
                removeCcCollaborator: function(e) {
                    e.preventDefault()
                    if (Backbone.\$(e.currentTarget).parent()[0]) {
                        Backbone.\$(e.currentTarget).parent()[0].removeChild(e.currentTarget);
                        var collaboratorContainer = \$('.uv-element-block.collaborators');
                    }

                    if(!collaboratorContainer.find('.uv-btn-tag').length)
                        collaboratorContainer.hide()
                },
                showCcBccBlock: function(e) {
                    var currentElement = Backbone.\$(e.currentTarget);
                    var currentTab = currentElement.parents('.uv-tab-view');
                    if(currentElement.is(':checked')) {
                        currentTab.find('.uv-element-block.cc-bcc').find('.uv-field-block').show()
                    } else {
                        currentTab.find('.uv-element-block.cc-bcc').find('.uv-field-block').hide()
                        currentTab.find('.uv-element-block .cc-bcc-list').html('')
                    }
                },
                addCcBccInput: function(e) {
                    var inputElement = Backbone.\$(e.currentTarget);
                    var currentTab = inputElement.parents('.uv-tab-view');
                    var email = inputElement.val().trim();
                    if (e.which === 13 && email) {
                        e.preventDefault()
                        type = currentTab.find('.cc-bcc-select option:selected').text()
                        if(!this.model.preValidate({name: 'email', email: email})) {
                            inputName = \$('.cc-bcc-select').val()
                            inputElement.val('').trigger('input')
                            inputElement.removeClass('uv-dropdown-btn-active')
                            inputElement.siblings('.uv-dropdown-list').hide()
                            if(!currentTab.find(\".cc-bcc-list input[value='\" + email + \"'].\" + inputName).length) {
                                currentTab.find('.cc-bcc-list').append(\"<span><input type='hidden' name='\" + inputName + \"[]' value='\" + email + \"' class='\" + inputName + \"'/><a class=uv-btn-tag uv-lowercase' href='#'><span class='uv-icon-remove-dark-before'></span>\" + email + \" : <span class='uv-uppercase'>\" + type + \"</span></a></span>\")
                            }
                        }
                    }
                },
                removeEmail: function(e) {
                    e.preventDefault()
                    Backbone.\$(e.currentTarget).parent().remove();
                },
                validateForm : function(e) {
                    e.preventDefault();
                    var element = Backbone.\$(e.currentTarget);
                    form = \$('#ticket-form');
                    form.find('.reply-status').val(element.attr('data-id'));
                    form.find('.uv-field-message').remove()

                    var html = tinyMCE.get(\"reply-area\").getContent();
                    if(app.appView.htmlText(html) != '' || -1 != html.indexOf('<img')) {
                        this.stopDraftSaveFlag = 1;

\t\t\t\t\t\tapp.appView.showLoader();
                        tinyMCE.activeEditor.uploadImages(function(response) {
                            app.appView.hideLoader();

\t\t\t\t\t\t\tform.submit();
\t                        \$('.uv-dropdown.reply').find('.uv-btn').attr('disabled', 'disabled');
\t                        \$('#reply-btn,#confirmed-close-ticket').attr('disabled', 'disabled');
                        });
                    } else {
                        form.find('.uv-element-block-textarea').append(\"<span class='uv-field-message'>";
        // line 624
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("This field is mandatory"), "html", null, true);
        echo "</span>\");
                    }
                }
            });

            var ThreadModel = Backbone.Model.extend({
                idAttribute : \"id\",
                defaults : {
                    hasTask : 0,
                    task: null
                }
            });

            var ThreadCollection = AppCollection.extend({
                model : ThreadModel,
                mode: \"infinite\",
                url : \"";
        // line 640
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("helpdesk_customer_thread_collection_xhr", ["id" => twig_get_attribute($this->env, $this->source, (isset($context["ticket"]) || array_key_exists("ticket", $context) ? $context["ticket"] : (function () { throw new RuntimeError('Variable "ticket" does not exist.', 640, $this->source); })()), "id", [], "any", false, false, false, 640)]), "html", null, true);
        echo "\",
                parseRecords: function (resp, options) {
                    return resp.threads;
                },
                syncData : function() {
                    app.appView.showLoader()
                    this.fetch({
                        remove: false,
                        success: function(model, response) {
                            app.appView.hideLoader()
                            pagination.renderPagination(response.pagination);
                            threadCollection.state.currentPage = parseInt(response.pagination.current) + 1;
                        },
                        error: function (model, xhr, options) {
                            app.appView.hideLoader()
                            if(url = xhr.getResponseHeader('Location'))
                                window.location = url;
                        }
                    });
                }
            });

            var ThreadItem = Backbone.View.extend({
                tagName : \"div\",
                className : \"uv-ticket-main\",
                template : _.template(\$(\"#thread_list_item_tmp\").html()),
                render : function () {
                    this.\$el.html(this.template(this.model.toJSON()));
                    this.\$el.addClass(\"thread-\" + this.model.id)

                    return this;
                }
            });

            var ThreadList = Backbone.View.extend({
                el : \$(\".thread-list\"),
                initialize : function() {
                    this.listenTo(threadCollection.fullCollection, \"add\", this.renderThread);
                },
                renderThread : function (item) {
                    var threadItem = new ThreadItem({
                        model: item
                    });
                    if(item.id < threadCollection.fullCollection.at(0).id)
                        this.\$el.prepend(threadItem.render().el);
                    else
                        this.\$el.append(threadItem.render().el);
                    threadItem.\$el.find('.helpdesk_blockquote').eq(0).before(\"<span class='uv-icon-ellipsis uv-ellipsis-mirror'></span>\").hide();
                    //emojifyRun();
                    this.\$el.find('img').removeAttr('crossorigin');
                    //viewerImages();
                    //convertForImages(this.\$el);
                    this.\$el.find('div.message a').attr('target', '_blank');
                    app.appView.relativeTime()
                }
            });

            var Pagination = Backbone.View.extend({
                el: \$('.uv-ticket-accordion'),
                events: {
                    'click .uv-ticket-count-stat': 'loadMore',
                },
                renderPagination: function(pagination) {
                    if(pagination.totalCount - pagination.lastItemNumber > 0 && pagination.lastItemNumber > 0) {
                        var remain = pagination.totalCount - pagination.lastItemNumber;
                        \$('.uv-ticket-count-stat').text(remain)
                        \$('.uv-ticket-accordion').removeClass('uv-ticket-accordion-expanded').removeClass('uv-ticket-accordion-no-count')
                    } else {
                        \$('.uv-ticket-accordion').addClass('uv-ticket-accordion-expanded').addClass('uv-ticket-accordion-no-count')
                    }
                },
                loadMore: function() {
                    threadCollection.syncData();
                }
            });

            //Collaborator Code starts here
            _.extend(Backbone.Model.prototype, Backbone.Validation.mixin);
            var CollaboratorModel = Backbone.Model.extend({
                idAttribute : \"id\",
                validation: {
                    'email': [{
                        required: true,
                        msg: '";
        // line 723
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("This field is mandatory"), "html", null, true);
        echo "'
                    },{
                        pattern: 'email',
                        msg: '";
        // line 726
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Please enter a valid email"), "html", null, true);
        echo "'
                    }]
                },
                defaults : {
                    ticketId : ";
        // line 730
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["ticket"]) || array_key_exists("ticket", $context) ? $context["ticket"] : (function () { throw new RuntimeError('Variable "ticket" does not exist.', 730, $this->source); })()), "id", [], "any", false, false, false, 730), "html", null, true);
        echo ",
                    email: ''
                },
                parse: function (resp, options) {
                    return resp.collaborator;
                },
                urlRoot : \"";
        // line 736
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("helpdesk_customer_update_ticket_collaborators_xhr");
        echo "\"
            });

            var CollaboratorCollection = Backbone.PageableCollection.extend({
                model : CollaboratorModel
            });

            var CollaboratorItem = Backbone.View.extend({
                tagName : \"a\",
                className: 'uv-btn-tag',
                template : _.template(\"<span class='uv-tag'><span class='uv-icon-remove-dark-before'></span><%- name %></span>\"),
                events : {
                    'click .uv-tag' : 'removeItem'
                },
                render : function () {
                    this.\$el.html(this.template(this.model.toJSON()));
                    return this;
                },
                unrender : function(response) {
                    if(response.alertMessage != undefined) {
                        collaboratorListView.render();
                        app.appView.renderResponseAlert(response);
                    }
                },
                removeItem: function() {
                    self = this;
                    app.appView.showLoader();
                    this.model.destroy({
                        data : { 'ticketId' : this.model.attributes.ticketId },
                        success : function (model, response, options) {
                            app.appView.hideLoader();
                            self.\$el.remove();
                            self.unrender(response);
                        },
                        error: function (model, xhr, options) {
                            if(url = xhr.getResponseHeader('Location'))
                                window.location = url;
                            var response = warningResponse;
                            if(xhr.responseJSON)
                                response = xhr.responseJSON;

                            app.appView.hideLoader();
                            app.appView.renderResponseAlert(response);
                        }
                    });
                }
            });

            var CollaboratorList = Backbone.View.extend({
                el : \$(\".collaborator-list-block\"),
                events : {
                    'keypress .uv-field' : 'addCollaborator',
                    'focusout .uv-field' : 'removeErrorClass',
                },
                initialize : function() {
                    //Backbone.Validation.bind(this);
                },
                render : function() {
                    this.\$el.find(\".collaborator-list\").html('');
                    var self = this;
                    collaboratorOptionHtml = '';
                    if(collaboratorCollection.length) {
                        _.each(collaboratorCollection.models, function (item) {
                            this.renderCollaborator(item);
                        }, this);
                    }
                    ticketView.addCCCollaborators()
                },
                renderCollaborator : function (item) {
                    var collaborator = new CollaboratorItem({
                        model: item
                    });
                    this.\$el.find('.collaborator-list').append(collaborator.render().el);
                },
                removeErrorClass: function(e) {
                    var inputElement = Backbone.\$(e.currentTarget);
                    inputElement.removeClass('uv-field-error');
                    inputElement.parents('.uv-element-block').find('.uv-field-message').remove()
                },
                addCollaborator : function(e) {
                    var inputElement = Backbone.\$(e.currentTarget);
                    inputElement.removeClass('uv-field-error');
                    inputElement.parents('.uv-element-block').find('.uv-field-message').remove()
                    var text = inputElement.val().trim();

                    if (e.which === 13 && text) {
                        this.model = new CollaboratorModel();
                        self = this;
                        this.model.set({email: text})

                        if(this.model.isValid(true)) {
                            app.appView.showLoader();
                            this.model.save({},{
                                success : function (model, response, options) {
                                    inputElement.val('');
                                    if(response.alertClass == \"success\") {
                                        collaboratorCollection.add(model);
                                    }
                                    self.render();
                                    app.appView.hideLoader();
                                    app.appView.renderResponseAlert(response);
                                },
                                error: function (model, xhr, options) {
                                    if(url = xhr.getResponseHeader('Location'))
                                        window.location = url;
                                    var response = warningResponse;
                                    if(xhr.responseJSON)
                                        response = xhr.responseJSON;

                                    app.appView.hideLoader();
                                    app.appView.renderResponseAlert(response);
                                }
                            });
                        } else {
                            inputElement.addClass('uv-field-error');
                            if(text)
                                inputElement.parents('.uv-element-block').append(\"<span class='uv-field-message'>";
        // line 852
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Email address is invalid"), "html", null, true);
        echo "</span>\");
                        }
                    }
                }
            });
            //Collaborator Code ends here

            ticketModel = new TicketModel({
                id : \"";
        // line 860
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["ticket"]) || array_key_exists("ticket", $context) ? $context["ticket"] : (function () { throw new RuntimeError('Variable "ticket" does not exist.', 860, $this->source); })()), "id", [], "any", false, false, false, 860), "html", null, true);
        echo "\",
            });

            ticketApp.ticketView = ticketView = new TicketView({
                model: ticketModel
            });

            var threadCollection = new ThreadCollection();
\t\t    var threadList = new ThreadList();
            var pagination = new Pagination();
            threadCollection.syncData();

            ";
        // line 872
        if ((twig_get_attribute($this->env, $this->source, (isset($context["ticket"]) || array_key_exists("ticket", $context) ? $context["ticket"] : (function () { throw new RuntimeError('Variable "ticket" does not exist.', 872, $this->source); })()), "customer", [], "any", false, false, false, 872) == twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 872, $this->source); })()), "user", [], "any", false, false, false, 872))) {
            // line 873
            echo "                var collaboratorCollection = new CollaboratorCollection(\$.parseJSON('";
            echo json_encode(twig_get_attribute($this->env, $this->source, (isset($context["ticket_service"]) || array_key_exists("ticket_service", $context) ? $context["ticket_service"] : (function () { throw new RuntimeError('Variable "ticket_service" does not exist.', 873, $this->source); })()), "getTicketCollaborators", [0 => twig_get_attribute($this->env, $this->source, (isset($context["ticket"]) || array_key_exists("ticket", $context) ? $context["ticket"] : (function () { throw new RuntimeError('Variable "ticket" does not exist.', 873, $this->source); })()), "id", [], "any", false, false, false, 873)], "method", false, false, false, 873));
            echo "'));
                var collaboratorListView = new CollaboratorList();
                collaboratorListView.render();
            ";
        }
        // line 877
        echo "        });
    </script>

    ";
        // line 880
        echo twig_include($this->env, $context, "@UVDeskCoreFramework/Templates/tinyMCE.html.twig");
        echo "

\t<script>
\t\tsfTinyMce.init({
            height: '250px',
\t\t\tselector : '.uv-ticket-reply textarea',
\t\t\timages_upload_url: \"\",
            setup: function(editor) {
            }
\t\t});
\t</script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "@UVDeskSupportCenter/Knowledgebase/ticketView.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  1384 => 880,  1379 => 877,  1371 => 873,  1369 => 872,  1354 => 860,  1343 => 852,  1224 => 736,  1215 => 730,  1208 => 726,  1202 => 723,  1116 => 640,  1097 => 624,  995 => 525,  989 => 522,  963 => 502,  948 => 489,  927 => 473,  922 => 471,  912 => 464,  907 => 462,  898 => 456,  885 => 446,  880 => 445,  870 => 444,  855 => 438,  851 => 437,  845 => 434,  841 => 433,  817 => 412,  813 => 411,  808 => 409,  798 => 402,  789 => 396,  780 => 389,  775 => 387,  763 => 378,  759 => 377,  750 => 371,  736 => 360,  729 => 356,  722 => 352,  718 => 350,  712 => 348,  705 => 346,  703 => 345,  688 => 333,  679 => 326,  675 => 324,  665 => 321,  661 => 319,  659 => 318,  656 => 317,  647 => 314,  640 => 313,  636 => 312,  631 => 310,  628 => 309,  626 => 308,  619 => 303,  613 => 301,  607 => 299,  605 => 298,  596 => 292,  589 => 288,  583 => 284,  579 => 280,  574 => 278,  569 => 276,  565 => 275,  555 => 267,  549 => 264,  545 => 263,  542 => 262,  540 => 261,  535 => 259,  531 => 258,  524 => 254,  518 => 253,  514 => 252,  506 => 247,  498 => 241,  486 => 232,  481 => 230,  477 => 229,  473 => 227,  471 => 226,  468 => 225,  458 => 218,  453 => 216,  448 => 213,  446 => 212,  443 => 211,  437 => 208,  433 => 207,  430 => 206,  428 => 205,  423 => 203,  419 => 202,  416 => 201,  410 => 198,  406 => 197,  403 => 196,  400 => 195,  394 => 192,  390 => 191,  387 => 190,  385 => 189,  378 => 185,  373 => 183,  367 => 180,  362 => 178,  357 => 176,  351 => 172,  348 => 171,  345 => 170,  342 => 169,  339 => 168,  337 => 167,  196 => 28,  186 => 27,  170 => 20,  166 => 19,  161 => 16,  153 => 14,  151 => 13,  145 => 12,  139 => 8,  129 => 7,  107 => 5,  85 => 4,  63 => 3,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"@UVDeskSupportCenter/Templates/layout.html.twig\" %}

{% block title %}#{{ ticket.id }} {{ ticket.subject }}{% endblock %}
{% block ogtitle %}#{{ ticket.id }} {{ ticket.subject }}{% endblock %}
{% block twtitle %}#{{ ticket.id }} {{ ticket.subject }}{% endblock %}

{% block tabHeader %}
\t<div class=\"uv-nav-bar uv-nav-tab\">
\t\t<div class=\"uv-container\">
\t\t\t<div class=\"uv-nav-bar-lt\">
\t\t\t\t<ul class=\"uv-nav-tab-label\">
\t\t\t\t\t<li><a href=\"{{ path('helpdesk_customer_ticket_collection') }}\">{{ 'Ticket Requests'|trans }}</a></li>
\t\t\t\t\t{% if websiteConfiguration.ticketCreateOption %}
                        <li><a href=\"{{ path('helpdesk_customer_create_ticket') }}\">{{ 'New Ticket Request'|trans }}</a></li>
                    {% endif %}
\t\t\t\t</ul>
\t\t\t</div>
\t\t\t<div class=\"uv-nav-bar-rt\">
\t\t\t\t<form method=\"get\" action=\"{{path('helpdesk_customer_front_article_search')}}\">
\t\t\t\t\t<input name=\"s\" class=\"uv-nav-search\" type=\"text\" placeholder=\"{{ 'Search'|trans }}\">
\t\t\t\t</form>
\t\t\t</div>
\t\t</div>
\t</div>
{% endblock %}

{% block body %}
    <style>
        .uv-btn-tag {
            margin-right: 5px;
        }
        .uv-group-field {
            width: 80%;
        }
        .uv-element-block .mce-tinymce {
            margin-top: 10px;
        }
        .uv-ticket-view .uv-ticket-accordion .uv-ticket-wrapper {
            display: block;
        }
        .message {
            font-size: 15px;
        }
        .message img {
            max-width: 100%;
        }
        .uv-dropdown.reply .uv-dropdown-btn-active {
            border: none;
        }
        .uv-dropdown.reply .uv-dropdown-list {
            width: 220px;
            bottom: 47px;
        }

\t\t.uv-rtl .uv-top-left {
\t\t\tleft: unset;
\t\t}

\t\t.uv-rtl .uv-dropdown-list {
\t\t\ttext-align: right;
\t\t}

        .uv-action-buttons {
            margin: 10px 0px;
        }

        .uv-action-buttons .uv-btn:first-child {
            margin-left: 0px;
        }

\t\t.uv-rtl .uv-action-buttons .uv-btn:first-child {
\t\t\tmargin-left: 5px;
\t\t\tmargin-right: 0px;
\t\t}

        .uv-action-buttons .uv-btn {
            margin: 5px;
        }

        form #customFieldCollection .uv-field-error-icon, form #customFieldCollection .uv-field-success-icon {
            display: none;
        }

        .custom-field-field-display .uv-field-block {
            width: 100%;
            color: #333333;
            word-wrap: break-word;
        }

        .custom-field-field-display .uv-field-block span {
            display: inline;
        }
        .uv-submit-left-side {
            margin: 0!important;
            padding-right: 5px;
            border-bottom-right-radius: 0;
            border-top-right-radius: 0;
        }
\t\t.uv-rtl .uv-submit-left-side {
\t\t\tpadding-right: 10px;
            border-bottom-right-radius: 3px;
            border-top-right-radius: 3px;
\t\t\tpadding-left: 5px;
\t\t\tborder-bottom-left-radius: 0;
            border-top-left-radius: 0;
\t\t}
        .uv-submit-right-side {
            margin: 0!important;
        }
        .no-left-padding {
            padding-left: 0;
            border-bottom-left-radius: 0;
            border-top-left-radius: 0;
        }
\t\t.uv-rtl .no-left-padding {
\t\t\tpadding-left: 10px;
            border-bottom-left-radius: 3px;
            border-top-left-radius: 3px;
\t\t\tpadding-right: 0;
\t\t\tborder-bottom-right-radius: 0;
\t\t\tborder-top-right-radius: 0;
\t\t}
        .uv-btn-error {
            background-color: #FF5656!important;
        }
        .uv-pull-rightside {
            float: right;
            font-size: 15px;
            cursor: pointer;
        }
\t\t.uv-rtl .uv-pull-rightside {
            float: left;
        }
        .uv-print-icon {
            display: inline-block;
            width: 20px;
            height: 20px;
            background-image: url('../../../../../bundles/webkuldefault/images/uvdesk-kb-sprite.svg');
            background-position: -176px -91px;
            vertical-align: middle;
        }
        @media print {
            .uv-navbar,.uv-ticket-action-bar, .uv-kudo, .uv-aside-back, .uv-footer, .uv-ticket-main.uv-ticket-reply, .uv-nav-bar,input, .uv-dropdown-list>.uv-dropdown-container,.uv-notifications-wrapper,.uv-pop-up-overlay,.uv-loader-view, .uv-loader,.uv-header,.uv-upload-actions,.uv-pull-rightside {
                display: none !important;
            }
        }
        blockquote {
            background: #f9f9f9;
            border-left: 4px solid #ccc;
            margin: 1.5em 10px;
            padding: 0.5em 10px;
            quotes: \"\\201C\"\"\\201D\"\"\\2018\"\"\\2019\";
        }
        blockquote:before {
            color: #ccc;
            content: open-quote;
            font-size: 3em;
            line-height: 0.1em;
            margin-right: 0.05em;
            vertical-align: -0.4em;
        }
        blockquote p {
            display: inline;
        }
    </style>

    {% set ticketAgent = ticket.agent ? user_service.getAgentDetailById(ticket.agent.id) : null %}
    {% set totalThreads = ticket_service.getTicketTotalThreads(ticket.id) %}
    {% set customer = user_service.getCustomerPartialDetailById(ticket.customer.id)  %}
    {% set createThread = ticket_service.getCreateReply(ticket.id, 'customer') %}
    {% set currentUser = user_service.getCustomerPartialDetailById(app.user.id)  %}

    <div class=\"uv-thread\">
        <div class=\"uv-thread-lt\">
            <aside>
                <h6>{{ 'Ticket Information'|trans }}</h6>
                <div class=\"uv-aside-brick\">
                    <h6>{{ 'Total Replies'|trans }}</h6>
                    <span class=\"uv-icon-replies\"></span>
                    <span>{{ totalThreads }}</span>
                </div>
                <div class=\"uv-aside-brick\">
                    <h6>{{ 'Timestamp'|trans }}</h6>
                    <span class=\"uv-icon-timestamp\"></span>
                    <span>{{ localizedCreateAtTime }}</span>
                </div>

                <div class=\"uv-hr\"></div>
                {% if ticket.customer != app.user %}
                    <div class=\"uv-aside-brick\">
                        <h6>{{ 'Customer'|trans }}</h6>
                        <span>{{ customer.name }}</span>
                    </div>
                {% endif %}
                {% if ticketAgent %}
                    <div class=\"uv-aside-brick\">
                        <h6>{{ 'Agent'|trans }}</h6>
                        <span>{{ ticketAgent.name }}</span>
                    </div>
                {% endif %}
                <div class=\"uv-aside-brick\">
                    <h6>{{ 'Status'|trans }}</h6>
                    <span>{{ ticket.status.description|trans }}</span>
                </div>
                {% if ticket.type %}
                    <div class=\"uv-aside-brick\">
                        <h6>{{ 'Type'|trans }}</h6>
                        <span>{{ ticket.type.code }}</span>
                    </div>
                {% endif %}

                {% if ticket.customer == app.user %}
                    <div class=\"uv-hr\"></div>
                    <div class=\"uv-aside-brick collaborator-list-block\">
                        <div class=\"uv-element-block\">
                            <label class=\"uv-field-label\">{{ 'Collaborators'|trans }}</label>
                            <div class=\"uv-field-block\">
                                <input class=\"uv-field\" type=\"text\" name=\"email\" type=\"text\" value=\"\" placeholder=\"{{ 'Type email to add'|trans }}\">
                            </div>
                        </div>
                        <div class=\"collaborator-list\" style=\"margin-top: 10px\">
                        </div>
                    </div>
                {% endif %}
            </aside>
            {% if customFieldCollection is defined %}
                <aside id=\"uv-customfield-view\" class=\"uv-customfield-view\" style=\"margin-top: 20px;\">
                    <div style=\"position: relative;\">
                        <h6>{{ 'Custom Field'|trans }}</h6>
                        <span class=\"uv-customize cfield-manage-pta\" style=\"width: 15px; height: 15px; position: absolute; background-image: url('../../../../../bundles/webkuldefault/images/uvdesk-sprite.svg'); background-position: -44px -46px; top: 4px; cursor: pointer;\" title=\"{{ 'Manage Ticket Custom Fields'|trans }}\" data-toggle=\"tooltip\" data-placement=\"bottom\"></span>
                    </div>
                    <p style=\"padding-right: 20px; color: #6F6F6F; font-style: italic;\">{{ 'Manage Custom Fields to provide additional details with the ticket.'|trans }}</p>

                    <div class=\"uv-hr\"></div>
                    <form name=\"customFieldForm\" enctype=\"multipart/form-data\">
                        <div id=\"customFieldCollection\">
                        </div>
                    </form>
                </aside>
            {% endif %}
        </div>
        <div class=\"uv-thread-rt\">
            <section>
                <div class=\"uv-ticket-view\">
                    <div class=\"uv-ticket-head\">
                        <h1>
                            {{ ticket.subject }}
                            <span class=\"uv-pull-rightside uv-print-icon\" onclick=\"window.print()\"></span>
                        </h1>
                        <div class=\"uv-ticket-strip\">
                            <span>
                                <span class=\"uv-ticket-strip-label\">{{ 'Created'|trans }} -</span>
                                <span class=\"timeago\" data-timestamp=\"{{ localizedCreateAtTime }}\" title=\"{{ localizedCreateAtTime }}\">
                                    {{ localizedCreateAtTime }} 
                                </span>
                            </span>
                            <span>
                                <span class=\"uv-ticket-strip-label\">{{ 'By'|trans }} -</span>
                                {{ createThread.user.name }}
                            </span>
                            {% if ticketAgent %}
                                <span>
                                    <span class=\"uv-ticket-strip-label\">{{ 'Agent'|trans }} -</span>
                                    {{ ticketAgent.name }}
                                </span>
                            {% endif %}
                        </div>
                    </div>

                    <div class=\"uv-tab-view\">
                        <div class=\"uv-ticket-section\">
                            <div class=\"uv-ticket-main create\">
                                <div class=\"uv-ticket-strip\">
                                    <span>
                                        <span class=\"timeago uv-margin-0\" data-timestamp=\"ticket.createdAt\" title=\"{{ localizedCreateAtTime }}\">
                                            {{ localizedCreateAtTime }}
                                        </span>
                                        - {{ createThread.user.name }}
                                        <span class=\"uv-ticket-strip-label\">
                                        {{ 'created Ticket'|trans }}
                                        {# {% if ticket.ipAddress %}
                                            ({{ 'IP'|trans }} -{{ ticket.ipAddress }})
                                        {% endif %} #}
                                    </span>
                                </span>
                                </div>
                                <div class=\"uv-ticket-main-lt\">
                                   <img src=\"{{ initialThread.user.thumbnail ? app.request.scheme ~'://' ~ app.request.httpHost ~ asset('') ~ (initialThread.user.thumbnail) : initialThread.createdBy == 'customer' ? asset(default_customer_image_path) : asset(default_agent_image_path) }}\">
                                </div>
                                <div class=\"uv-ticket-main-rt\">
                                    <span class=\"uv-ticket-member-name\">
                                        {{ createThread.user.name }}
                                    </span>

                                    <!-- Message Block -->
                                    <div class=\"message\">
                                        <p>
                                            {% if createThread.reply|striptags == createThread.reply %}
                                                {{ createThread.reply|nl2br }}
                                            {% else %}
                                                {{ createThread.reply|raw }}
                                            {% endif %}
                                        </p>
                                    </div>
                                    <!-- //Message Block -->

                                    <!-- Attachment Block -->
                                    {% if createThread.attachments|length %}
                                        <div class=\"uv-ticket-uploads\">
                                            <h4>{{ 'Uploaded Files'|trans }}</h4>
                                            <div class=\"uv-ticket-uploads-strip uv-viewer-images\">
                                                {% for attachment in createThread.attachments %}
                                                    <a href=\"{{ attachment.downloadURL }}\" target = \"_blank\" class=\"uv-ticket-uploads-brick uv-no-pointer-events\" data-toggle=\"tooltip\" title=\"{{ attachment.name }}\">
                                                        <img src=\"{{ attachment.iconURL }}\"  class=\"uv-auto-pointer-events\"/>
                                                    </a>
                                                {% endfor %}
                                            </div>
                                            {% if createThread.attachments|length > 1 %}
                                                <div class=\"uv-upload-actions\">
                                                    <!-- <a href=\"#\"><span class=\"uv-icon-open-in-files\"></span>Open in Files</a> -->
                                                    <a href=\"{{ path('helpdesk_customer_download_ticket_attachment_zip') }}/{{createThread.id}}\" target=\"_blank\"><span class=\"uv-icon-attachment\"></span> {{ 'Download (as .zip)'|trans }}</a>
                                                </div>
                                            {% endif %}
                                        </div>
                                    {% endif %}
                                    <!-- //Attachment Block -->
                                </div>
                            </div>

                            <!-- uv-ticket-accordion-expanded uv-ticket-accordion-no-count-->
                            <div class=\"uv-ticket-accordion\">
                                <div class=\"uv-ticket-count-wrapper\">
                                    <span class=\"uv-ticket-count-stat\">{{ totalThreads }}</span>
                                </div>
                                <div class=\"uv-ticket-wrapper thread-list\">
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Reply Form Block -->
                    <div class=\"uv-ticket-main uv-ticket-reply uv-no-error-success-icon\">
                        <div class=\"uv-ticket-main-lt\">
                            <span class=\"uv-icon-ellipsis\"></span>
                            {% if currentUser.smallThumbnail %}
                                <img src=\"{{ app.request.scheme ~'://' ~ app.request.httpHost ~ asset('') }}{{ currentUser.smallThumbnail }}\" />
                            {% else %}
                                <img src=\"{{ asset(default_customer_image_path) }}\" />
                            {% endif %}
                        </div>
                        <div class=\"uv-ticket-main-rt\">
                            <span class=\"uv-ticket-member-name\">{{ currentUser.name }}</span>

                            <!-- Reply Tab View -->
                            <div class=\"uv-tab-view uv-tab-view-active\" id=\"reply\">
                                <form enctype=\"multipart/form-data\" method=\"post\" action=\"{{ path('helpdesk_customer_add_ticket_thread', {'id': ticket.id }) }}\" id=\"ticket-form\">
                                    <input name=\"threadType\" value=\"reply\" type=\"hidden\">
                                    <input class=\"reply-status\" name=\"status\" value=\"\" type=\"hidden\">
                                    <div class=\"uv-element-block collaborators\" style=\"display: none\">
                                        <label class=\"uv-field-label\">{{ 'Collaborators'|trans }}</label>
                                        <div class=\"uv-field-block\">
                                        </div>
                                    </div>

                                    <div class=\"uv-element-block cc-bcc\">
                                        <label>
                                            <div class=\"uv-checkbox\">
                                                <input type=\"checkbox\" class=\"cc-bcc-toggle\">
                                                <span class=\"uv-checkbox-view\"></span>
                                            </div>
                                            <span class=\"uv-checkbox-label\">{{ 'CC/BCC'|trans }}</span>
                                        </label>
                                        <div class=\"uv-field-block\" style=\"display: none\">
                                            <div class=\"uv-group\">
                                                <input class=\"uv-group-field\" type=\"text\">
                                                <select class=\"uv-group-select cc-bcc-select\">
                                                    <option value=\"bcc\">{{ 'BCC'|trans }}</option>
                                                    <option value=\"cc\">{{ 'CC'|trans }}</option>
                                                </select>
                                            </div>
                                            <div class=\"cc-bcc-list\">
                                            </div>
                                        </div>
                                    </div>

                                    <div class=\"uv-element-block uv-element-block-textarea\">
                                        <label class=\"uv-field-label\">{{ 'Write a reply'|trans }}</label>
                                        <div class=\"uv-field-block\">
                                            <textarea class=\"uv-field\" name=\"message\" id=\"reply-area\">{# {{ ticket_service.getCustomerDraft(ticket.id, 'reply') }} #}</textarea>
                                        </div>
                                    </div>

                                    <!-- Field -->
                                    <div class=\"uv-element-block attachment-block\">
                                        <label>
                                            <span class=\"uv-file-label\">{{ 'Add Attachment'|trans }}</span>
                                        </label>
                                    </div>
                                    <!-- //Field -->

                                    <div class=\"uv-action-buttons\">
                                        <div id=\"reply-btn\" class=\"uv-btn uv-submit-left-side\">{{ 'Reply'|trans }}</div>
                                        <div class=\"uv-dropdown reply uv-submit-right-side\">
                                            <div class=\"uv-btn uv-dropdown-other no-left-padding\">
                                                <span class=\"uv-icon-down-light\"></span>
                                            </div>
                                            <div class=\"uv-dropdown-list uv-top-left\">
                                                <div class=\"uv-dropdown-container\">
                                                    <label>{{ 'Reply'|trans }}</label>
                                                    <ul>
                                                        <li data-id=\"\">{{ 'Submit'|trans }}</li>
                                                        <li class=\"confirm-close-ticket\" data-id=\"closed\">{{ 'Submit And Closed'|trans }}</li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <!-- //Reply Tab View -->
                        </div>
                    </div>
                    <!-- Reply Form Block -->
                </div>
            </section>
        </div>
        </div>
    </div>

    <div class=\"uv-pop-up-overlay\" id=\"confirm-ticket-close-modal\" style=\"display: none;\">
        <div class=\"uv-pop-up-box uv-pop-up-slim\">
            <span class=\"uv-pop-up-close\"></span>
            <h2>{{ 'Confirm Close Ticket'|trans }}</h2>
            <p>{{ 'Are you sure? You want to reply and close ticket.'|trans }}</p>

            <div class=\"uv-pop-up-actions\">
                <a href=\"#\" class=\"uv-btn uv-btn-error\" id=\"confirmed-close-ticket\" data-id=\"closed\">{{ 'Confirm'|trans }}</a>
                <a href=\"#\" class=\"uv-btn cancel\">{{ 'Cancel'|trans }}</a>
            </div>
        </div>
    </div>
{% endblock %}

{% block footer %}
    {{ parent() }}
    {{ include('@UVDeskCoreFramework/Templates/attachment.html.twig') }}

    <script id=\"thread_list_item_tmp\" type=\"text/template\">
        <div class=\"uv-ticket-strip\">
            <span>
                <span class=\"timeago uv-margin-0\" data-timestamp=\"<%= timestamp %>\" title=\"<%= formatedCreatedAt %>\">
                    <%= formatedCreatedAt %>
                </span>
                - <%- fullname %>
                <span class=\"uv-ticket-strip-label\">
                    {{ 'replied'|trans }}
                </span>
            </span>
            <% if(cc || bcc) { %>
                <div class=\"uv-ticket-strip\">
                    <% if(cc) { %>
                        <span><span class=\"uv-ticket-strip-label\">{{ 'CC'|trans }} -</span> <%- cc %></span>
                    <% } if(bcc) { %>
                        <span><span class=\"uv-ticket-strip-label\">{{ 'BCC'|trans }} -</span> <%- bcc %></span>
                    <% } %>
                </div>
            <% } %>
        </div>
        <div class=\"uv-ticket-main-lt\">
            <% if(user && smallThumbnail != null) { %>
                <img src=\"{{ app.request.scheme ~'://' ~ app.request.httpHost ~ asset('') }}<%= smallThumbnail %>\" />
            <% } else { %>
                <img src=\"<% if(userType == 'agent') { %> {{ asset(default_agent_image_path) }} <% } else { %> {{ asset(default_customer_image_path) }} <% } %>\" />
            <% } %>
        </div>
        <div class=\"uv-ticket-main-rt\">
            <span class=\"uv-ticket-member-name\">
                <%- fullname %>
            </span>
            <!-- Message Block -->
            <div class=\"message\">
                <%= reply %>
            </div>
            <!-- //Message Block -->

            <!-- Attachment Block -->
            <% if(attachments.length) { %>
                <div class=\"uv-ticket-uploads\">
                    <h4>{{ 'Uploaded Files'|trans }}</h4>
                    <div class=\"uv-ticket-uploads-strip uv-viewer-images\">
                        <% _.each(attachments, function(file) { %>
                            <a href=\"<%-file.downloadURL %>\" target =\"_blank\" class=\"uv-ticket-uploads-brick uv-no-pointer-events\" data-toggle=\"tooltip\" title=\"<%- file.name %>\">
                                <img src=\"<%-file.iconURL %>\" class=\"uv-auto-pointer-events\">
                            </a>
                        <% }) %>
                    </div>

                    <% if (attachments.length > 1) { %>
                        <div class=\"thread-attachments-zip pull-left\">
                            <div class=\"uv-upload-actions\">
                                {#<a href=\"#\"><span class=\"uv-icon-open-in-files\"></span>Open in Files</a>#}
                                <a href=\"{{ path('helpdesk_customer_download_ticket_attachment_zip') }}/<%= id %>\" target=\"_blank\"><span class=\"uv-icon-attachment\"></span> {{ 'Download (as .zip)'|trans }}</a>
                            </div>
                        </div>
                    <% } %>
                </div>
            <% } %>
            <!-- //Attachment Block -->
        </div>
    </script>

    <script type=\"text/javascript\">

        var ticketApp = {};
        \$(function () {
            
            var TicketModel = Backbone.Model.extend({
                idAttribute : \"id\",
                validation: {
                    'email': [{
                        required: true,
                        msg: '{{ \"This field is mandatory\"|trans }}'
                    },{
                        pattern: 'email',
                        msg: '{{ \"Please enter a valid email\"|trans }}'
                    }],
                },
            });

            var TicketView = Backbone.View.extend({
                el: \$('.uv-body'),
                stopDraftSaveFlag: 0,
                events: {
                    'click .collaborator-list .uv-btn-tag': 'removeCcCollaborator',
                    'change .uv-element-block.cc-bcc .cc-bcc-toggle': 'showCcBccBlock',
                    'keypress .uv-element-block.cc-bcc .uv-group-field': 'addCcBccInput',
                    'click .cc-bcc-list .uv-btn-tag, .to-list .uv-btn-tag': 'removeEmail',
                    'click .uv-dropdown.reply .uv-dropdown-list li:not(.confirm-close-ticket)': 'validateForm',
                    'click #reply-btn': 'validateForm',
                    'click #confirmed-close-ticket': 'confirmedAction',
                    'click .confirm-close-ticket': 'confirmClose',
                },
                confirmClose: function(e) {
                    \$('#confirm-ticket-close-modal').show();
                },
                confirmedAction: function(e) {
                    \$('#confirm-ticket-close-modal').hide();
                    this.validateForm(e);
                },
                loaderTemplate : _.template(\$(\"#loader-tmp\").html()),
                addCCCollaborators: function() {
                    if(collaboratorCollection.length) {
                        var collaboratorContainer = \$('.uv-element-block.collaborators');
                        collaboratorContainer.find('.uv-field-block').html('');
                        collaboratorContainer.show()
                        _.each(collaboratorCollection.models, function (item) {
                            var json = item.attributes;
                            collaboratorContainer.find('.uv-field-block').append(\"<span><input type='hidden' name='cccol[]' value='\" + json.email + \"'/><a class='uv-btn-tag' href='#'><span class='uv-icon-remove-dark-before'></span>\" + json.name + \"</a></span>\")
                        }, this);
                    }
                },
                removeCcCollaborator: function(e) {
                    e.preventDefault()
                    if (Backbone.\$(e.currentTarget).parent()[0]) {
                        Backbone.\$(e.currentTarget).parent()[0].removeChild(e.currentTarget);
                        var collaboratorContainer = \$('.uv-element-block.collaborators');
                    }

                    if(!collaboratorContainer.find('.uv-btn-tag').length)
                        collaboratorContainer.hide()
                },
                showCcBccBlock: function(e) {
                    var currentElement = Backbone.\$(e.currentTarget);
                    var currentTab = currentElement.parents('.uv-tab-view');
                    if(currentElement.is(':checked')) {
                        currentTab.find('.uv-element-block.cc-bcc').find('.uv-field-block').show()
                    } else {
                        currentTab.find('.uv-element-block.cc-bcc').find('.uv-field-block').hide()
                        currentTab.find('.uv-element-block .cc-bcc-list').html('')
                    }
                },
                addCcBccInput: function(e) {
                    var inputElement = Backbone.\$(e.currentTarget);
                    var currentTab = inputElement.parents('.uv-tab-view');
                    var email = inputElement.val().trim();
                    if (e.which === 13 && email) {
                        e.preventDefault()
                        type = currentTab.find('.cc-bcc-select option:selected').text()
                        if(!this.model.preValidate({name: 'email', email: email})) {
                            inputName = \$('.cc-bcc-select').val()
                            inputElement.val('').trigger('input')
                            inputElement.removeClass('uv-dropdown-btn-active')
                            inputElement.siblings('.uv-dropdown-list').hide()
                            if(!currentTab.find(\".cc-bcc-list input[value='\" + email + \"'].\" + inputName).length) {
                                currentTab.find('.cc-bcc-list').append(\"<span><input type='hidden' name='\" + inputName + \"[]' value='\" + email + \"' class='\" + inputName + \"'/><a class=uv-btn-tag uv-lowercase' href='#'><span class='uv-icon-remove-dark-before'></span>\" + email + \" : <span class='uv-uppercase'>\" + type + \"</span></a></span>\")
                            }
                        }
                    }
                },
                removeEmail: function(e) {
                    e.preventDefault()
                    Backbone.\$(e.currentTarget).parent().remove();
                },
                validateForm : function(e) {
                    e.preventDefault();
                    var element = Backbone.\$(e.currentTarget);
                    form = \$('#ticket-form');
                    form.find('.reply-status').val(element.attr('data-id'));
                    form.find('.uv-field-message').remove()

                    var html = tinyMCE.get(\"reply-area\").getContent();
                    if(app.appView.htmlText(html) != '' || -1 != html.indexOf('<img')) {
                        this.stopDraftSaveFlag = 1;

\t\t\t\t\t\tapp.appView.showLoader();
                        tinyMCE.activeEditor.uploadImages(function(response) {
                            app.appView.hideLoader();

\t\t\t\t\t\t\tform.submit();
\t                        \$('.uv-dropdown.reply').find('.uv-btn').attr('disabled', 'disabled');
\t                        \$('#reply-btn,#confirmed-close-ticket').attr('disabled', 'disabled');
                        });
                    } else {
                        form.find('.uv-element-block-textarea').append(\"<span class='uv-field-message'>{{ 'This field is mandatory'|trans }}</span>\");
                    }
                }
            });

            var ThreadModel = Backbone.Model.extend({
                idAttribute : \"id\",
                defaults : {
                    hasTask : 0,
                    task: null
                }
            });

            var ThreadCollection = AppCollection.extend({
                model : ThreadModel,
                mode: \"infinite\",
                url : \"{{ path('helpdesk_customer_thread_collection_xhr', {'id': ticket.id}) }}\",
                parseRecords: function (resp, options) {
                    return resp.threads;
                },
                syncData : function() {
                    app.appView.showLoader()
                    this.fetch({
                        remove: false,
                        success: function(model, response) {
                            app.appView.hideLoader()
                            pagination.renderPagination(response.pagination);
                            threadCollection.state.currentPage = parseInt(response.pagination.current) + 1;
                        },
                        error: function (model, xhr, options) {
                            app.appView.hideLoader()
                            if(url = xhr.getResponseHeader('Location'))
                                window.location = url;
                        }
                    });
                }
            });

            var ThreadItem = Backbone.View.extend({
                tagName : \"div\",
                className : \"uv-ticket-main\",
                template : _.template(\$(\"#thread_list_item_tmp\").html()),
                render : function () {
                    this.\$el.html(this.template(this.model.toJSON()));
                    this.\$el.addClass(\"thread-\" + this.model.id)

                    return this;
                }
            });

            var ThreadList = Backbone.View.extend({
                el : \$(\".thread-list\"),
                initialize : function() {
                    this.listenTo(threadCollection.fullCollection, \"add\", this.renderThread);
                },
                renderThread : function (item) {
                    var threadItem = new ThreadItem({
                        model: item
                    });
                    if(item.id < threadCollection.fullCollection.at(0).id)
                        this.\$el.prepend(threadItem.render().el);
                    else
                        this.\$el.append(threadItem.render().el);
                    threadItem.\$el.find('.helpdesk_blockquote').eq(0).before(\"<span class='uv-icon-ellipsis uv-ellipsis-mirror'></span>\").hide();
                    //emojifyRun();
                    this.\$el.find('img').removeAttr('crossorigin');
                    //viewerImages();
                    //convertForImages(this.\$el);
                    this.\$el.find('div.message a').attr('target', '_blank');
                    app.appView.relativeTime()
                }
            });

            var Pagination = Backbone.View.extend({
                el: \$('.uv-ticket-accordion'),
                events: {
                    'click .uv-ticket-count-stat': 'loadMore',
                },
                renderPagination: function(pagination) {
                    if(pagination.totalCount - pagination.lastItemNumber > 0 && pagination.lastItemNumber > 0) {
                        var remain = pagination.totalCount - pagination.lastItemNumber;
                        \$('.uv-ticket-count-stat').text(remain)
                        \$('.uv-ticket-accordion').removeClass('uv-ticket-accordion-expanded').removeClass('uv-ticket-accordion-no-count')
                    } else {
                        \$('.uv-ticket-accordion').addClass('uv-ticket-accordion-expanded').addClass('uv-ticket-accordion-no-count')
                    }
                },
                loadMore: function() {
                    threadCollection.syncData();
                }
            });

            //Collaborator Code starts here
            _.extend(Backbone.Model.prototype, Backbone.Validation.mixin);
            var CollaboratorModel = Backbone.Model.extend({
                idAttribute : \"id\",
                validation: {
                    'email': [{
                        required: true,
                        msg: '{{ \"This field is mandatory\"|trans }}'
                    },{
                        pattern: 'email',
                        msg: '{{ \"Please enter a valid email\"|trans }}'
                    }]
                },
                defaults : {
                    ticketId : {{ ticket.id }},
                    email: ''
                },
                parse: function (resp, options) {
                    return resp.collaborator;
                },
                urlRoot : \"{{ path('helpdesk_customer_update_ticket_collaborators_xhr') }}\"
            });

            var CollaboratorCollection = Backbone.PageableCollection.extend({
                model : CollaboratorModel
            });

            var CollaboratorItem = Backbone.View.extend({
                tagName : \"a\",
                className: 'uv-btn-tag',
                template : _.template(\"<span class='uv-tag'><span class='uv-icon-remove-dark-before'></span><%- name %></span>\"),
                events : {
                    'click .uv-tag' : 'removeItem'
                },
                render : function () {
                    this.\$el.html(this.template(this.model.toJSON()));
                    return this;
                },
                unrender : function(response) {
                    if(response.alertMessage != undefined) {
                        collaboratorListView.render();
                        app.appView.renderResponseAlert(response);
                    }
                },
                removeItem: function() {
                    self = this;
                    app.appView.showLoader();
                    this.model.destroy({
                        data : { 'ticketId' : this.model.attributes.ticketId },
                        success : function (model, response, options) {
                            app.appView.hideLoader();
                            self.\$el.remove();
                            self.unrender(response);
                        },
                        error: function (model, xhr, options) {
                            if(url = xhr.getResponseHeader('Location'))
                                window.location = url;
                            var response = warningResponse;
                            if(xhr.responseJSON)
                                response = xhr.responseJSON;

                            app.appView.hideLoader();
                            app.appView.renderResponseAlert(response);
                        }
                    });
                }
            });

            var CollaboratorList = Backbone.View.extend({
                el : \$(\".collaborator-list-block\"),
                events : {
                    'keypress .uv-field' : 'addCollaborator',
                    'focusout .uv-field' : 'removeErrorClass',
                },
                initialize : function() {
                    //Backbone.Validation.bind(this);
                },
                render : function() {
                    this.\$el.find(\".collaborator-list\").html('');
                    var self = this;
                    collaboratorOptionHtml = '';
                    if(collaboratorCollection.length) {
                        _.each(collaboratorCollection.models, function (item) {
                            this.renderCollaborator(item);
                        }, this);
                    }
                    ticketView.addCCCollaborators()
                },
                renderCollaborator : function (item) {
                    var collaborator = new CollaboratorItem({
                        model: item
                    });
                    this.\$el.find('.collaborator-list').append(collaborator.render().el);
                },
                removeErrorClass: function(e) {
                    var inputElement = Backbone.\$(e.currentTarget);
                    inputElement.removeClass('uv-field-error');
                    inputElement.parents('.uv-element-block').find('.uv-field-message').remove()
                },
                addCollaborator : function(e) {
                    var inputElement = Backbone.\$(e.currentTarget);
                    inputElement.removeClass('uv-field-error');
                    inputElement.parents('.uv-element-block').find('.uv-field-message').remove()
                    var text = inputElement.val().trim();

                    if (e.which === 13 && text) {
                        this.model = new CollaboratorModel();
                        self = this;
                        this.model.set({email: text})

                        if(this.model.isValid(true)) {
                            app.appView.showLoader();
                            this.model.save({},{
                                success : function (model, response, options) {
                                    inputElement.val('');
                                    if(response.alertClass == \"success\") {
                                        collaboratorCollection.add(model);
                                    }
                                    self.render();
                                    app.appView.hideLoader();
                                    app.appView.renderResponseAlert(response);
                                },
                                error: function (model, xhr, options) {
                                    if(url = xhr.getResponseHeader('Location'))
                                        window.location = url;
                                    var response = warningResponse;
                                    if(xhr.responseJSON)
                                        response = xhr.responseJSON;

                                    app.appView.hideLoader();
                                    app.appView.renderResponseAlert(response);
                                }
                            });
                        } else {
                            inputElement.addClass('uv-field-error');
                            if(text)
                                inputElement.parents('.uv-element-block').append(\"<span class='uv-field-message'>{{ 'Email address is invalid'|trans }}</span>\");
                        }
                    }
                }
            });
            //Collaborator Code ends here

            ticketModel = new TicketModel({
                id : \"{{ ticket.id }}\",
            });

            ticketApp.ticketView = ticketView = new TicketView({
                model: ticketModel
            });

            var threadCollection = new ThreadCollection();
\t\t    var threadList = new ThreadList();
            var pagination = new Pagination();
            threadCollection.syncData();

            {% if ticket.customer == app.user %}
                var collaboratorCollection = new CollaboratorCollection(\$.parseJSON('{{ ticket_service.getTicketCollaborators(ticket.id)|json_encode|raw }}'));
                var collaboratorListView = new CollaboratorList();
                collaboratorListView.render();
            {% endif %}
        });
    </script>

    {{ include(\"@UVDeskCoreFramework/Templates/tinyMCE.html.twig\") }}

\t<script>
\t\tsfTinyMce.init({
            height: '250px',
\t\t\tselector : '.uv-ticket-reply textarea',
\t\t\timages_upload_url: \"\",
            setup: function(editor) {
            }
\t\t});
\t</script>
{% endblock %}
", "@UVDeskSupportCenter/Knowledgebase/ticketView.html.twig", "/var/www/udvesk/helpdesk-project/vendor/uvdesk/support-center-bundle/Resources/views/Knowledgebase/ticketView.html.twig");
    }
}
